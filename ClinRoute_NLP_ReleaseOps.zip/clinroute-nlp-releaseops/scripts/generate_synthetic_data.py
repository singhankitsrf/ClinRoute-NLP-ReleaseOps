from __future__ import annotations

import argparse
import random
from pathlib import Path

import pandas as pd

ROUTES = {
    "otology": {
        "symptoms": ["ear pain", "ear discharge", "blocked ear", "recurrent ear infection", "hearing change"],
        "findings": ["inflamed tympanic membrane", "perforated tympanic membrane", "middle ear effusion", "retracted tympanic membrane"],
    },
    "audiology": {
        "symptoms": ["gradual hearing loss", "difficulty understanding speech", "tinnitus", "hearing difficulty"],
        "findings": ["failed hearing screen", "reduced hearing threshold", "asymmetric hearing concern", "hearing aid review requested"],
    },
    "rhinology": {
        "symptoms": ["nasal obstruction", "recurrent sinus pressure", "reduced smell", "persistent nasal discharge"],
        "findings": ["deviated nasal septum", "nasal polyp suspected", "chronic rhinosinusitis symptoms", "recurrent epistaxis"],
    },
    "laryngology": {
        "symptoms": ["persistent hoarseness", "voice fatigue", "throat discomfort", "difficulty swallowing"],
        "findings": ["voice change for several weeks", "laryngeal symptoms", "persistent dysphonia", "swallowing concern"],
    },
    "general_ent": {
        "symptoms": ["neck swelling", "recurrent sore throat", "tonsil concern", "general ENT symptoms"],
        "findings": ["recurrent tonsillitis", "cervical lump under review", "persistent throat symptoms", "non-specific ENT complaint"],
    },
}

URGENCIES = {
    "routine": [
        "symptoms are stable and no red flags are reported",
        "routine specialist review is requested",
        "no acute deterioration is described",
    ],
    "expedited": [
        "symptoms are worsening and earlier specialist review is requested",
        "persistent symptoms are affecting daily function",
        "clinician requests accelerated review due to progression",
    ],
    "urgent": [
        "rapid deterioration is reported and urgent assessment is requested",
        "new severe symptoms require prompt specialist review",
        "red flag concern has been documented and urgent review is requested",
    ],
}


def generate(n: int, seed: int) -> pd.DataFrame:
    rng = random.Random(seed)
    ages = [18, 24, 31, 42, 55, 63, 71]
    durations = ["3 days", "1 week", "2 weeks", "6 weeks", "3 months", "8 months"]
    route_names = list(ROUTES)
    urgency_names = list(URGENCIES)
    rows = []

    for idx in range(n):
        route = route_names[idx % len(route_names)]
        urgency = urgency_names[(idx // len(route_names)) % len(urgency_names)]
        symptom = rng.choice(ROUTES[route]["symptoms"])
        finding = rng.choice(ROUTES[route]["findings"])
        urgency_phrase = rng.choice(URGENCIES[urgency])
        age = rng.choice(ages)
        duration = rng.choice(durations)
        email = f"synthetic.patient{idx}@example.test"
        phone = f"+91-90000-{idx % 100000:05d}"
        mrn = f"SYN-{100000 + idx}"
        templates = [
            f"Referral for a {age}-year-old adult with {symptom} for {duration}. Examination notes {finding}. {urgency_phrase}. Contact {email}; phone {phone}; MRN {mrn}.",
            f"ENT referral: {symptom} present for {duration}; {finding}. Patient is {age}. {urgency_phrase}. Synthetic MRN {mrn}, email {email}.",
            f"Reason for referral: {symptom}. Duration {duration}. Relevant finding: {finding}. {urgency_phrase}. Telephone {phone}. Reference {mrn}.",
        ]
        rows.append({
            "note_id": f"SYN-{idx:05d}",
            "text": rng.choice(templates),
            "route": route,
            "urgency": urgency,
            "synthetic": True,
        })

    rng.shuffle(rows)
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--output", default="data/synthetic_referrals.csv")
    args = ap.parse_args()

    frame = generate(args.rows, args.seed)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    print(f"Wrote {len(frame)} synthetic records to {output}")


if __name__ == "__main__":
    main()
