# Security and Privacy

## Included controls

- obvious demo identifiers are redacted before prediction output;
- maximum text length is enforced at the API schema;
- model output includes an explicit human-review path;
- Docker runs as a non-root user;
- Compose uses a read-only root filesystem;
- dependencies are scanned in CI;
- CodeQL is scheduled;
- container releases are tied to immutable commit SHAs;
- secrets and model binaries are excluded from Git.

## Important limitation

Regex-based identifier removal is **not** sufficient for certified medical
de-identification. Do not represent this repository as HIPAA/GDPR compliant
without appropriate organizational, legal, technical and validation work.
