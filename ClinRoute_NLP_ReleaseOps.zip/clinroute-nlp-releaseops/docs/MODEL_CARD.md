# Model Card

## Task

Two related NLP tasks from one referral note:

1. **Route classification** — `otology`, `audiology`, `rhinology`,
   `laryngology`, `general_ent`
2. **Operational urgency classification** — `routine`, `expedited`, `urgent`

## Architectures

- fast baseline: TF-IDF + Logistic Regression
- advanced candidate: dual-head transformer encoder

## Dataset status

The included dataset is **fully synthetic** and exists only for reproducible
software/CI demonstrations. It is not evidence of clinical performance.

## Human oversight

Predictions below configurable confidence thresholds are marked
`review_required=true`.

## Limitations

The identifier redaction module is deliberately described as best-effort demo
redaction. It is not certified de-identification. A real deployment requires
approved data governance, independently validated models, formal privacy controls,
subgroup evaluation and domain-specific clinical review.
