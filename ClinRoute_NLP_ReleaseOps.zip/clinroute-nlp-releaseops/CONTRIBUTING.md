# Contributing

Use feature branches and pull requests.

```bash
git checkout -b feature/calibration-gate
# edit
make check
git add .
git commit -m "feat: improve calibration regression gate"
git push -u origin feature/calibration-gate
```

ML changes should include:

- dataset/version description;
- candidate metrics;
- comparison with the approved baseline;
- known limitations;
- evidence that release-policy thresholds pass.
