# Recruiter / Interview Story

## 30-second pitch

“I built a production NLP platform where model quality is part of CI/CD. The
service uses a dual-head transformer to classify referral pathway and operational
urgency, with identifier redaction, entity extraction and confidence-based human
review. Pull requests run data-contract, type, unit, security and NLP smoke gates.
Candidate models must pass a regression policy before release, and version tags
publish immutable containers to GHCR.”

## Strong resume bullets

- Engineered a production NLP platform with a dual-head Transformer architecture
  for multi-task text routing and urgency classification, plus entity extraction
  and confidence-based human review.

- Designed model-aware CI/CD in GitHub Actions with data-contract checks, unit
  tests, static analysis, CodeQL, dependency monitoring and automated model
  regression gates based on macro-F1 and calibration.

- Implemented reproducible container releases to GitHub Container Registry using
  semantic version and immutable commit-SHA tags, enabling traceable rollback and
  release provenance.

## Interview themes

- transformer fine-tuning
- multi-task NLP
- text preprocessing and PII/PHI risk
- probability calibration
- model regression testing
- CI vs CD
- GitHub Actions
- immutable release artifacts
- security scanning
- rollback strategy
- model governance
