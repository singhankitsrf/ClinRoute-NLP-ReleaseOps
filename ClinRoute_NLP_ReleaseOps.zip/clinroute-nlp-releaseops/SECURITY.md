# Security Policy

Do not open public issues containing real patient data, credentials, access
tokens, private model artifacts or proprietary text corpora.

For a security issue in a real fork/deployment, use the repository's private
security-reporting mechanism where available.
