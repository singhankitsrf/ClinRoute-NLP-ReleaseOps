from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", required=True)
    ap.add_argument("--metrics", required=True)
    ap.add_argument("--output", default="artifacts/release_manifest.json")
    args = ap.parse_args()

    model_dir = Path(args.model_dir)
    files = []
    for path in sorted(model_dir.rglob("*")):
        if path.is_file():
            files.append({
                "path": path.relative_to(model_dir).as_posix(),
                "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size,
            })

    metrics = json.loads(Path(args.metrics).read_text(encoding="utf-8"))
    manifest = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_sha": os.getenv("GITHUB_SHA", "local"),
        "git_ref": os.getenv("GITHUB_REF_NAME", "local"),
        "model_dir": str(model_dir),
        "model_files": files,
        "metrics": metrics,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
