# CI/CD Design

## Pull-request gate

Every PR runs:

- Python 3.11 and 3.12 compatibility
- data-contract validation
- Ruff
- mypy
- pytest
- NLP contract smoke test
- Bandit
- a reproducible synthetic baseline training job

## Model regression gate

`model_regression_gate.py` compares candidate and currently approved metrics.

Default rules:

- candidate macro F1 may not regress by more than `0.01`
- candidate ECE may not worsen by more than `0.02`

The policy is configurable. Values are engineering examples, not clinical
acceptance criteria.

## Release gate

A semantic version tag such as `v0.2.0` triggers:

1. fresh quality verification;
2. container build;
3. push to GitHub Container Registry using both:
   - semantic version tag;
   - immutable Git commit SHA.

That dual tagging makes rollback and provenance straightforward.

## Security automation

- Bandit scans application Python code.
- CodeQL runs on pushes, PRs and a weekly schedule.
- Dependabot monitors Python, GitHub Actions and Docker dependencies.
- No registry password is needed for GHCR; the workflow uses the scoped
  `GITHUB_TOKEN`.
