from __future__ import annotations

import argparse
import json
import sys

def gate(candidate: dict, baseline: dict, f1_tolerance: float = 0.01, ece_tolerance: float = 0.02):
    failures = []
    for task in ("route", "urgency"):
        c = candidate[task]
        b = baseline[task]
        if c["macro_f1"] < b["macro_f1"] - f1_tolerance:
            failures.append(
                f"{task} macro_f1 regressed: {c['macro_f1']:.4f} < "
                f"{b['macro_f1'] - f1_tolerance:.4f}"
            )
        if c["ece"] > b["ece"] + ece_tolerance:
            failures.append(
                f"{task} ECE regressed: {c['ece']:.4f} > "
                f"{b['ece'] + ece_tolerance:.4f}"
            )
    return failures

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--f1-tolerance", type=float, default=0.01)
    ap.add_argument("--ece-tolerance", type=float, default=0.02)
    args = ap.parse_args()

    candidate = json.load(open(args.candidate, encoding="utf-8"))
    baseline = json.load(open(args.baseline, encoding="utf-8"))
    failures = gate(candidate, baseline, args.f1_tolerance, args.ece_tolerance)

    if failures:
        print("MODEL REGRESSION GATE: FAIL")
        for failure in failures:
            print("-", failure)
        sys.exit(1)

    print("MODEL REGRESSION GATE: PASS")

if __name__ == "__main__":
    main()
