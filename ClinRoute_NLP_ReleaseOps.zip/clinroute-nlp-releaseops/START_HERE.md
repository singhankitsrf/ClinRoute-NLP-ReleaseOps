# Start Here

For the fastest recruiter-ready setup:

1. Read `README.md`.
2. Run `python scripts/check_data_contract.py`.
3. Run `python training/train_baseline.py`.
4. Run `pytest -q`.
5. Launch the FastAPI service.
6. Push the repository to GitHub.
7. Confirm the CI and CodeQL workflows are green.
8. Create tag `v0.1.0` to publish the demo container to GHCR.
9. Train the Transformer candidate separately and add only real validation
   evidence to the README.
10. Pin this repository on your GitHub profile.

See `docs/GITHUB_UPLOAD_GUIDE.md` for exact commands.
