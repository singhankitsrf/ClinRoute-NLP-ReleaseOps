# GitHub Upload Guide

## 1. Create a public repository

Recommended name:

`clinroute-nlp-releaseops`

Recommended description:

`Production NLP + CI/CD: dual-head Transformer routing/urgency classification, entity extraction, model regression gates, FastAPI, Docker, CodeQL and GHCR releases.`

Do **not** initialize it with another README or `.gitignore`.

## 2. Extract the project ZIP

Open PowerShell or Terminal inside `clinroute-nlp-releaseops`.

## 3. Run locally before the first push

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install:

```bash
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

Validate:

```bash
python scripts/check_data_contract.py
ruff check .
mypy src
pytest -q
python scripts/api_contract_smoke.py
```

Train the fast synthetic baseline:

```bash
python training/train_baseline.py
```

## 4. Initialize Git

```bash
git init
git branch -M main
git add .
git status
git commit -m "feat: launch ClinRoute NLP ReleaseOps platform"
```

Confirm that no real patient data, model binaries, credentials or `.env` file is
staged.

## 5. Connect GitHub

```bash
git remote add origin https://github.com/YOUR_USERNAME/clinroute-nlp-releaseops.git
git push -u origin main
```

## 6. Suggested repository topics

`nlp`, `transformers`, `huggingface`, `pytorch`, `fastapi`, `cicd`,
`github-actions`, `mlops`, `model-regression`, `codeql`, `docker`,
`healthcare-ai`, `multi-task-learning`, `responsible-ai`

## 7. Enable repository features

In GitHub:

- **Settings → Actions → General**: allow GitHub Actions.
- **Security → Code scanning**: verify CodeQL results after the first run.
- **Insights → Dependency graph**: enable dependency graph if available.
- Keep Dependabot alerts enabled.

## 8. Publish your first container

After CI is green:

```bash
git tag v0.1.0
git push origin v0.1.0
```

The release workflow builds and publishes:

```text
ghcr.io/YOUR_USERNAME/clinroute-nlp-releaseops:v0.1.0
ghcr.io/YOUR_USERNAME/clinroute-nlp-releaseops:<commit-sha>
```

## 9. Pin the repository

GitHub profile → **Customize your pins** → pin this project with your other
flagship AI repositories.

## 10. Strengthen it after a real transformer run

Add only genuine artifacts:

- transformer validation metrics;
- confusion matrices;
- calibration plot;
- model-regression gate screenshot;
- successful CI pipeline screenshot;
- CodeQL/security status;
- GHCR package link;
- measured CPU/GPU inference latency.

Never present synthetic benchmark metrics as clinical performance.
