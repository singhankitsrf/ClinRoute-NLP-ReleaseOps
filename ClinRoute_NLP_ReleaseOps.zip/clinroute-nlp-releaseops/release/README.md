# Release Metrics

Do not commit fabricated candidate metrics.

For a real release, place the currently approved and candidate evaluation JSON
files here (or pass their paths to the workflow) and run:

```bash
python scripts/model_regression_gate.py \
  --baseline release/baseline_metrics.json \
  --candidate release/candidate_metrics.json
```

The repository tests use dedicated fixture values; those fixtures are not model
claims.
