# Architecture

```mermaid
flowchart LR
    A[Synthetic / approved text data] --> B[Data contract]
    B --> C[Baseline TF-IDF model]
    B --> D[Dual-head Transformer]
    D --> E[Route head]
    D --> F[Urgency head]
    E --> G[Confidence policy]
    F --> G
    A --> H[Identifier redaction]
    H --> I[Entity extraction]
    G --> J[FastAPI service]
    I --> J
    J --> K[Container image]
    K --> L[GitHub Container Registry]
```

## CI/CD control plane

```mermaid
flowchart TD
    PR[Pull request] --> QA[Lint + typing + tests]
    QA --> SEC[Bandit + CodeQL]
    SEC --> DATA[Data contract]
    DATA --> SMOKE[Synthetic baseline smoke]
    SMOKE --> MERGE[Merge]
    CAND[Candidate model metrics] --> GATE[Model regression gate]
    BASE[Approved baseline metrics] --> GATE
    GATE -->|pass| TAG[Version tag]
    GATE -->|fail| BLOCK[Block release]
    TAG --> BUILD[Build immutable container]
    BUILD --> GHCR[Push tag + commit SHA to GHCR]
```

## Design intent

The project treats **model quality as a release dependency**, not as an offline
research report. A candidate can fail CI/CD even when application tests pass if
its macro F1 or calibration regresses beyond configured tolerances.
