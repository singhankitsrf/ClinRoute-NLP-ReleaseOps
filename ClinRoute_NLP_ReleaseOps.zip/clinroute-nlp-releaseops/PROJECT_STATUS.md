# Project Status

## Completed

- 3,000-record reproducible synthetic NLP dataset
- five-class referral-routing task
- three-class urgency task
- TF-IDF / Logistic Regression baseline
- dual-head Transformer candidate architecture
- deployable Transformer predictor path
- identifier-redaction demo layer
- symptom/finding/duration entity extraction
- confidence-based human-review policy
- FastAPI service contract
- Docker baseline runtime
- separate Transformer Docker runtime
- model regression gate
- release provenance manifest with SHA-256 model-file hashes
- GitHub Actions CI
- semantic tag → GHCR container release workflow
- CodeQL workflow
- Dependabot configuration
- security/privacy/model-card documentation
- recruiter/interview positioning documentation

## Validation performed during repository generation

- data contract: PASS
- synthetic baseline training: PASS
- NLP contract smoke test: PASS
- unit tests: **8 passed**
- Python compile check: PASS
- GitHub Actions YAML parsing: PASS for all workflows
- release-manifest generation: PASS

## Intentionally not claimed

The dual-head Transformer was not trained in the artifact-generation environment,
because that requires downloading pretrained model assets and preferably GPU
compute. The training and inference code are included, but no Transformer metric
is fabricated.

The included baseline benchmark is against synthetic data only and must not be
presented as clinical validation or real-world performance.
