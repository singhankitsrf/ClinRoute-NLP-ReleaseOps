# API Contract

## `GET /health`

Returns service readiness and whether a model bundle was loaded.

## `POST /analyze`

Request:

```json
{"text": "Persistent ear pain for 2 weeks. Urgent review requested."}
```

Response fields:

- `route`
- `route_confidence`
- `urgency`
- `urgency_confidence`
- `review_required`
- `redacted_text`
- `entities[]`
- `model_version`
- `disclaimer`

The API does not return a treatment recommendation or autonomous clinical
instruction.
