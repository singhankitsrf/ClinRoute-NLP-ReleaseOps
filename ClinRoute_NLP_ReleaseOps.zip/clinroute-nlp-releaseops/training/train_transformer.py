from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer

from clinroute.transformer_model import MultiTaskTransformer

class ReferralDataset(Dataset):
    def __init__(self, frame, tokenizer, route_map, urgency_map, max_length=256):
        self.frame = frame.reset_index(drop=True)
        self.tokenizer = tokenizer
        self.route_map = route_map
        self.urgency_map = urgency_map
        self.max_length = max_length

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, idx):
        row = self.frame.iloc[idx]
        enc = self.tokenizer(
            str(row["text"]), truncation=True, padding="max_length",
            max_length=self.max_length, return_tensors="pt"
        )
        return {
            "input_ids": enc["input_ids"][0],
            "attention_mask": enc["attention_mask"][0],
            "route": torch.tensor(self.route_map[row["route"]], dtype=torch.long),
            "urgency": torch.tensor(self.urgency_map[row["urgency"]], dtype=torch.long),
        }

def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def evaluate(model, loader, device):
    model.eval()
    rt, rp, ut, up = [], [], [], []
    with torch.inference_mode():
        for batch in loader:
            route_logits, urgency_logits = model(
                batch["input_ids"].to(device),
                batch["attention_mask"].to(device),
            )
            rt.extend(batch["route"].tolist())
            ut.extend(batch["urgency"].tolist())
            rp.extend(route_logits.argmax(1).cpu().tolist())
            up.extend(urgency_logits.argmax(1).cpu().tolist())
    return {
        "route_macro_f1": float(f1_score(rt, rp, average="macro")),
        "urgency_macro_f1": float(f1_score(ut, up, average="macro")),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/synthetic_referrals.csv")
    ap.add_argument("--encoder", default="distilroberta-base")
    ap.add_argument("--output", default="models/transformer")
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--max-length", type=int, default=256)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    seed_all(args.seed)
    frame = pd.read_csv(args.data)
    train, val = train_test_split(
        frame, test_size=0.20, random_state=args.seed,
        stratify=frame["route"].astype(str) + "::" + frame["urgency"].astype(str),
    )

    routes = sorted(frame["route"].unique().tolist())
    urgencies = sorted(frame["urgency"].unique().tolist())
    route_map = {x:i for i,x in enumerate(routes)}
    urgency_map = {x:i for i,x in enumerate(urgencies)}

    tokenizer = AutoTokenizer.from_pretrained(args.encoder)
    train_ds = ReferralDataset(train, tokenizer, route_map, urgency_map, args.max_length)
    val_ds = ReferralDataset(val, tokenizer, route_map, urgency_map, args.max_length)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = MultiTaskTransformer(args.encoder, len(routes), len(urgencies)).to(device)
    optimizer = AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    loss_fn = nn.CrossEntropyLoss()

    best = -1.0
    best_state = None
    history = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            route_logits, urgency_logits = model(
                batch["input_ids"].to(device),
                batch["attention_mask"].to(device),
            )
            route_loss = loss_fn(route_logits, batch["route"].to(device))
            urgency_loss = loss_fn(urgency_logits, batch["urgency"].to(device))
            loss = route_loss + urgency_loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))

        result = evaluate(model, val_loader, device)
        result["epoch"] = epoch
        result["train_loss"] = float(np.mean(losses))
        history.append(result)
        score = (result["route_macro_f1"] + result["urgency_macro_f1"]) / 2
        print(json.dumps(result))

        if score > best:
            best = score
            best_state = {k:v.detach().cpu() for k,v in model.state_dict().items()}

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    model.load_state_dict(best_state)
    tokenizer.save_pretrained(out / "tokenizer")
    model.encoder.save_pretrained(out / "encoder")
    torch.save(model.state_dict(), out / "multitask_state.pt")
    metadata = {
        "encoder": args.encoder,
        "route_labels": routes,
        "urgency_labels": urgencies,
        "max_length": args.max_length,
        "validation_history": history,
        "benchmark_scope": "synthetic_data_only",
    }
    (out / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    (out / "VERSION").write_text("dual-head-transformer-synthetic-v1\n", encoding="utf-8")

if __name__ == "__main__":
    main()
